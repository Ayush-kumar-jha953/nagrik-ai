"""
db.py  -  PostgreSQL connection helper.

NAGRIK AI uses THREE separate PostgreSQL databases (as requested):
    image   -> table picture_uploaded   (posts)
    upvote  -> table count              (like counts)
    comment -> table num                (comments)
"""
import os
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

PG = {
    "host": os.getenv("PGHOST", "localhost"),
    "port": os.getenv("PGPORT", "5432"),
    "user": os.getenv("PGUSER", "postgres"),
    "password": os.getenv("PGPASSWORD", "your password"),
}

DB_IMAGE = "image"
DB_UPVOTE = "upvote"
DB_COMMENT = "comment"


def get_conn(dbname):
    """Open a connection to one of the three databases."""
    return psycopg2.connect(dbname=dbname, cursor_factory=RealDictCursor, **PG)
