"""
auth.py  -  YOUR login page code, kept as it was, packaged as a Flask Blueprint
so it can live inside the NAGRIK AI app (app.py registers it).

Only 3 things differ from your original file:
  1. Flask(...) / @app.route  ->  Blueprint / @auth_bp.route
  2. dbname " nagrik_db" (it had a leading space)  ->  "nagrik_db"
  3. after login/signup it redirects to the Home page (/home) instead of /main_content
"""
from flask import Blueprint, render_template, request, redirect, session, url_for
import os
import psycopg2
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash, check_password_hash

load_dotenv()   # reads the local ".env" file (never uploaded to git)

auth_bp = Blueprint("auth", __name__)

# ---------- PostgreSQL settings: values come from the .env file ----------
DB_CONFIG = {
    "host": os.getenv("PGHOST", "localhost"),
    "port": int(os.getenv("PGPORT", "5432")),
    "dbname": os.getenv("LOGIN_DB_NAME", "nagrik_db"),
    "user": os.getenv("PGUSER", "postgres"),
    "password": os.getenv("PGPASSWORD", "your password"),
}


def get_db():
    return psycopg2.connect(**DB_CONFIG)


def create_table():
    """Creates the users table if it does not exist yet."""
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)
    conn.commit()
    cur.close()
    conn.close()


@auth_bp.route("/", methods=["GET", "POST"])
def login():
    error = None

    if request.method == "POST":
        name = request.form["name"].strip()
        username = request.form["username"].strip()
        password = request.form["password"]

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT password FROM users WHERE username = %s", (username,))
        row = cur.fetchone()

        if row is None:
            # First time: save the new user
            cur.execute(
                "INSERT INTO users (name, username, password) VALUES (%s, %s, %s)",
                (name, username, generate_password_hash(password)),
            )
            conn.commit()
            cur.close()
            conn.close()
            session["username"] = username
            return redirect(url_for("home"))          # -> main Home page

        cur.close()
        conn.close()

        # Existing user: check the password
        if check_password_hash(row[0], password):
            session["username"] = username
            return redirect(url_for("home"))          # -> main Home page

        error = "Incorrect user_name or password"

    return render_template("login.html", error=error)


@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
