"""
init_db.py  -  Run ONCE before starting the app:   python init_db.py
Creates the 3 databases and their tables.
"""
import psycopg2
from db import PG, DB_IMAGE, DB_UPVOTE, DB_COMMENT

TABLES = {
    DB_IMAGE: """
        CREATE TABLE IF NOT EXISTS picture_uploaded (
            id          SERIAL PRIMARY KEY,
            user_id     TEXT NOT NULL,
            category    TEXT NOT NULL,
            description TEXT NOT NULL,
            filename    TEXT NOT NULL,
            created_at  TIMESTAMP DEFAULT NOW()
        );""",
    DB_UPVOTE: """
        CREATE TABLE IF NOT EXISTS count (
            post_id INTEGER PRIMARY KEY,
            likes   INTEGER NOT NULL DEFAULT 0
        );""",
    DB_COMMENT: """
        CREATE TABLE IF NOT EXISTS num (
            id            SERIAL PRIMARY KEY,
            post_id       INTEGER NOT NULL,
            post_owner_id TEXT NOT NULL,
            commenter_id  TEXT NOT NULL,
            comment_text  TEXT NOT NULL,
            created_at    TIMESTAMP DEFAULT NOW()
        );""",
}


def main():
    admin = psycopg2.connect(dbname="postgres", **PG)
    admin.autocommit = True
    cur = admin.cursor()
    for name in TABLES:
        cur.execute("SELECT 1 FROM pg_database WHERE datname = %s", (name,))
        if not cur.fetchone():
            cur.execute(f'CREATE DATABASE "{name}"')
            print(f"created database {name}")
    admin.close()

    for name, ddl in TABLES.items():
        conn = psycopg2.connect(dbname=name, **PG)
        with conn, conn.cursor() as c:
            c.execute(ddl)
        conn.close()
        print(f"table ready in {name}")


if __name__ == "__main__":
    main()