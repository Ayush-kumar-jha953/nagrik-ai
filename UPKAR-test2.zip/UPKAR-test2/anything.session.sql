INSERT INTO users (id, name, username, password)
VALUES (
    id:integer,
    'name:text',
    'username:text',
    'password:text'
  );