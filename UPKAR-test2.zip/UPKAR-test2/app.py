"""
app.py  -  Flask backend for NAGRIK AI
Run:  python app.py
"""
import os
import random
import uuid
from flask import Flask, render_template, request, session, jsonify, redirect, url_for
from db import get_conn, DB_IMAGE, DB_UPVOTE, DB_COMMENT
from auth import auth_bp, create_table      # your login page (auth.py)

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key")
app.register_blueprint(auth_bp)             # login lives at "/"
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB

UPLOAD_DIR = os.path.join(app.root_path, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

ALLOWED_EXT = {"jpg", "jpeg", "png"}
CATEGORIES = ["Climate Issue", "Healthcare", "Education", "Sanitation", "Infrastructure"]


# ---------------------------------------------------------------- helpers
@app.before_request
def ensure_user():
    """Login required. The logged-in username becomes the citizen ID everywhere."""
    if request.endpoint in ("auth.login", "auth.logout", "static"):
        return                                   # public: login page + static files
    if "username" not in session:
        return redirect(url_for("auth.login"))
    session["user_id"] = session["username"]
    session.setdefault("liked", [])
    session.permanent = True


def valid_image(file):
    """Accept only real JPG / PNG (extension + magic bytes)."""
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED_EXT:
        return None
    head = file.stream.read(8)
    file.stream.seek(0)
    if head.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    return None


def fetch_posts(only_user=None):
    """Posts from DB 'image' + like counts from DB 'upvote' + comments from DB 'comment'."""
    with get_conn(DB_IMAGE) as c, c.cursor() as cur:
        if only_user:
            cur.execute("SELECT * FROM picture_uploaded WHERE user_id=%s ORDER BY id DESC", (only_user,))
        else:
            cur.execute("SELECT * FROM picture_uploaded ORDER BY id DESC")
        posts = cur.fetchall()
    if not posts:
        return []
    ids = [p["id"] for p in posts]

    with get_conn(DB_UPVOTE) as c, c.cursor() as cur:
        cur.execute("SELECT post_id, likes FROM count WHERE post_id = ANY(%s)", (ids,))
        likes = {r["post_id"]: r["likes"] for r in cur.fetchall()}

    with get_conn(DB_COMMENT) as c, c.cursor() as cur:
        cur.execute("SELECT * FROM num WHERE post_id = ANY(%s) ORDER BY id", (ids,))
        comments = {}
        for r in cur.fetchall():
            comments.setdefault(r["post_id"], []).append(r)

    for p in posts:
        p["likes"] = likes.get(p["id"], 0)
        p["comments"] = comments.get(p["id"], [])
        p["liked_by_me"] = p["id"] in session.get("liked", [])
    return posts


# ----------------------------------------------------------------- pages
@app.route("/home")                              # was "/" ; "/" is now the login page
def home():
    return render_template("home.html", posts=fetch_posts(), categories=CATEGORIES, active="home")


@app.route("/problems")
def problems():
    mine = fetch_posts(only_user=session["user_id"])
    return render_template("problems.html", posts=mine, categories=CATEGORIES, active="problems")


@app.route("/notifications")
def notifications():
    """Comments that OTHER citizens wrote on MY posts."""
    with get_conn(DB_COMMENT) as c, c.cursor() as cur:
        cur.execute(
            "SELECT * FROM num WHERE post_owner_id=%s AND commenter_id<>%s ORDER BY id DESC",
            (session["user_id"], session["user_id"]),
        )
        items = cur.fetchall()
    return render_template("notifications.html", items=items, categories=CATEGORIES, active="notifications")


@app.route("/profile")
def profile():
    return render_template("profile.html", categories=CATEGORIES, active="profile")


@app.route("/settings")
def settings():
    return render_template("settings.html", categories=CATEGORIES, active="settings")


# ------------------------------------------------------------------- APIs
@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("image")
    category = request.form.get("category", "")
    description = request.form.get("description", "").strip()

    if not file or file.filename == "":
        return jsonify(error="Please choose an image."), 400
    if category not in CATEGORIES:
        return jsonify(error="Please select a valid category."), 400
    if len(description) < 10:
        return jsonify(error="Please describe the problem in detail (min 10 characters)."), 400
    ext = valid_image(file)
    if not ext:
        return jsonify(error="Only JPG or PNG images are allowed."), 400

    filename = f"{uuid.uuid4().hex}.{ext}"
    file.save(os.path.join(UPLOAD_DIR, filename))

    with get_conn(DB_IMAGE) as c, c.cursor() as cur:
        cur.execute(
            "INSERT INTO picture_uploaded (user_id, category, description, filename) "
            "VALUES (%s,%s,%s,%s) RETURNING id",
            (session["user_id"], category, description, filename),
        )
        post_id = cur.fetchone()["id"]

    # start the like counter at 0 in DB 'upvote'
    with get_conn(DB_UPVOTE) as c, c.cursor() as cur:
        cur.execute("INSERT INTO count (post_id, likes) VALUES (%s, 0) ON CONFLICT DO NOTHING", (post_id,))

    return jsonify(ok=True, post_id=post_id)


@app.route("/like/<int:post_id>", methods=["POST"])
def like(post_id):
    """Toggle like. Number is stored in DB 'upvote', table 'count'."""
    liked = list(session.get("liked", []))
    delta = -1 if post_id in liked else 1
    if delta == 1:
        liked.append(post_id)
    else:
        liked.remove(post_id)
    session["liked"] = liked

    with get_conn(DB_UPVOTE) as c, c.cursor() as cur:
        cur.execute(
            "INSERT INTO count (post_id, likes) VALUES (%s, GREATEST(%s,0)) "
            "ON CONFLICT (post_id) DO UPDATE SET likes = GREATEST(count.likes + %s, 0) "
            "RETURNING likes",
            (post_id, delta, delta),
        )
        total = cur.fetchone()["likes"]
    return jsonify(likes=total, liked=delta == 1)


@app.route("/comment/<int:post_id>", methods=["POST"])
def comment(post_id):
    """Comment stored in DB 'comment', table 'num'."""
    text = (request.get_json(silent=True) or {}).get("text", "").strip()
    if not text:
        return jsonify(error="Comment cannot be empty."), 400

    with get_conn(DB_IMAGE) as c, c.cursor() as cur:
        cur.execute("SELECT user_id FROM picture_uploaded WHERE id=%s", (post_id,))
        row = cur.fetchone()
    if not row:
        return jsonify(error="Post not found."), 404

    with get_conn(DB_COMMENT) as c, c.cursor() as cur:
        cur.execute(
            "INSERT INTO num (post_id, post_owner_id, commenter_id, comment_text) VALUES (%s,%s,%s,%s)",
            (post_id, row["user_id"], session["user_id"], text),
        )
    return jsonify(ok=True, commenter=session["user_id"], text=text)


@app.route("/api/stats")
def stats():
    """Feeds the 'graphs' panel on the right side."""
    with get_conn(DB_IMAGE) as c, c.cursor() as cur:
        cur.execute("SELECT category, COUNT(*) AS n FROM picture_uploaded GROUP BY category")
        data = {r["category"]: r["n"] for r in cur.fetchall()}
    return jsonify([{"category": c, "count": data.get(c, 0)} for c in CATEGORIES])


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="Image too large (max 5 MB)."), 413


if __name__ == "__main__":
    create_table()                               # users table for login
    app.run(debug=True)